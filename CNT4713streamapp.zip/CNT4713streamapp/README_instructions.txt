live feed : python live_feed.py --ip localhost --port 8000 then get to localhost:8000 (for me this worked on Google Chrome)


static video : python using_webcam(opencv).py then go to localhost:5000/play (for me this worked on Microsoft Edge)

