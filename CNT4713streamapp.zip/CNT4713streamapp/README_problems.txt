Live Feed works on Google Chrome while Static Video works on Microsoft Edge.
Checked the Internet Information Services Manager for MIME type of mp4. It was already present.

When using ngrok command and copy pasting URL into browser, static video would display on webpage with the word "aborted".

Could not use heroku, trouble with buildpacks.