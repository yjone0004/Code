I was still having trouble with the live feed until I asked for help was recommended this tutorial
https://www.pyimagesearch.com/2019/09/02/opencv-stream-video-to-web-browser-html-page/
by Adrian Rosebrock

This tutorial was mainly for motion detection but it was the only way I had found to get the stream to work.