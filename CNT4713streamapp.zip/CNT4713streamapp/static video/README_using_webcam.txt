I began with the static video, I wanted to know how to use the camera as it seems the best place to start.
 I settled with OpenCV since I was able to find a tutorial that made sense to me.

https://www.youtube.com/watch?v=YNKo11c3EX0
Youtuber TECH DOSE

It helped me see the minimal requirements to get my camera working. 
I had tried before with VLC and other tutorials but I could not get very far.
