For the CVcapture html file I look at a blog from  https://www.lingulo.com/tutorials/how-to-build-an-html5-video-player-from-scratch
by Dustin Ford to understand how to use the HTML video tag

The picture of the stop sign and video of the flower are used in the HTML code.