
from flask import flask
from flask import render_template
import numpy as np 
import cv2

#create the app and set path to html files
app= Flask(__name__, template_folder="\\CNT4713streamapp\\static video\\templates")

#when you go to extension return the template
@app.route("/play")
def play():
	return render_template('CVcapture.html')


